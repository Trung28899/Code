This project is used to create an input form, store and display the information of the input
fields